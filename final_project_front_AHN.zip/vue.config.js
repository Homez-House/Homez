module.exports = {
  outputDir: "C:/Users/ahnda/git/final-project/src/main/resources/static",
};
