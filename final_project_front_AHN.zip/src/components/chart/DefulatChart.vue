<template>
  <div class="text-center">
    <img src='https://ifh.cc/g/T0OmVY.png' border='0'>
  </div>
</template>

<script>
export default {
  name: 'DefulatChart'
}
</script>

<style scoped>

</style>