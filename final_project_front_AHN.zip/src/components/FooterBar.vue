<template>
  <!-- Start Footer -->
  <footer class="bg-dark" id="tempaltemo_footer">
    <div class="container">
      <div class="row">
        <div class="col-md-4 pt-5">
          <h2 class="h2 text-success border-bottom pb-3 border-light logo">
            Homez
          </h2>
          <ul class="list-unstyled text-light footer-link-list">
            <li>
              <i class="fas fa-map-marker-alt fa-fw"></i>
              서울시 강남구 테헤란로 212
            </li>
            <li>
              <i class="fa fa-phone fa-fw"></i>
              <a class="text-decoration-none" href="tel:010-020-0340"
                >010-1234-5678</a
              >
            </li>
            <li>
              <i class="fa fa-envelope fa-fw"></i>
              <a class="text-decoration-none" href="mailto:info@company.com"
                >ssafy@ssafy.com</a
              >
            </li>
            <li>
              <i class="fas fa-child fa-fw"></i>
              <a class="text-decoration-none" href="#"
                >SSAFY 5기 13반 안대현 당현아</a
              >
            </li>
          </ul>
        </div>

        <div class="col-md-4 pt-5">
          <h2 class="h2 text-light border-bottom pb-3 border-light">
            Dev. History
          </h2>
          <ul class="list-unstyled text-light footer-link-list">
            <li><a class="text-decoration-none" href="#">프로젝트 협업</a></li>
            <li><a class="text-decoration-none" href="#">요구사항 정리</a></li>
            <li><a class="text-decoration-none" href="#">API 문서</a></li>
            <li>
              <a class="text-decoration-none" href="#">ERD 테이블 구조</a>
            </li>
            <li>
              <a class="text-decoration-none" href="#">클래스 다이어그램</a>
            </li>
            <li><a class="text-decoration-none" href="#">화면 설계서</a></li>
          </ul>
        </div>

        <div class="col-md-4 pt-5">
          <h2 class="h2 text-light border-bottom pb-3 border-light">Service</h2>
          <ul class="list-unstyled text-light footer-link-list">
            <li><a class="text-decoration-none" href="#">공지사항</a></li>
            <li>
              <a class="text-decoration-none" href="#">매물 동/이름 검색</a>
            </li>
            <li><a class="text-decoration-none" href="#">매물 상세 내역</a></li>
            <li><a class="text-decoration-none" href="#">주위 편의시설</a></li>
            <li><a class="text-decoration-none" href="#">이용자 정보</a></li>
            <li><a class="text-decoration-none" href="#">관리자 통계</a></li>
          </ul>
        </div>
      </div>

      <div class="row text-light mb-4">
        <div class="col-12 mb-3">
          <div class="w-100 my-3 border-top border-light"></div>
        </div>
        <div class="col-auto me-auto">
          <ul class="list-inline text-left footer-icons">
            <li
              class="
                list-inline-item
                border border-light
                rounded-circle
                text-center
              "
            >
              <a
                class="text-light text-decoration-none"
                target="_blank"
                href="https://www.ssafy.com/ksp/jsp/swp/swpMain.jsp"
                ><i class="fas fa-desktop"></i
              ></a>
            </li>
            <li
              class="
                list-inline-item
                border border-light
                rounded-circle
                text-center
              "
            >
              <a
                class="text-light text-decoration-none"
                target="_blank"
                href="https://github.com/daehyun1023"
                ><i class="fas fa-male"></i
              ></a>
            </li>
            <li
              class="
                list-inline-item
                border border-light
                rounded-circle
                text-center
              "
            >
              <a
                class="text-light text-decoration-none"
                target="_blank"
                href="https://github.com/eona1301"
                ><i class="fas fa-female"></i
              ></a>
            </li>
          </ul>
        </div>
        <div class="col-auto"></div>
      </div>
    </div>

    <div class="w-100 bg-black py-3">
      <div class="container">
        <div class="row pt-2">
          <div class="col-12">
            <p class="text-end text-light">
              Copyright &copy; 2021 SSAFY 5th 13 - Team 4 | Designed by
              <a rel="sponsored" href="https://templatemo.com" target="_blank"
                >TemplateMo</a
              >
            </p>
          </div>
        </div>
      </div>
    </div>
  </footer>
  <!-- End Footer -->
</template>

<script>
export default {
  name: "FooterBar",
};
</script>

<style scoped></style>
