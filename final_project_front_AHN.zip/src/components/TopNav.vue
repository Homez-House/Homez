<template>
    <nav class="navbar navbar-expand-lg bg-dark navbar-light d-none d-lg-block" id="templatemo_nav_top">
        <div class="container text-light">
            <div class="w-100 d-flex justify-content-between">
                <div>
                    <i class="fa fa-envelope mx-2"></i>
                    <a class="navbar-sm-brand text-light text-decoration-none" href="mailto:ssafy@ssafy.com">ssafy@ssafy.com</a>
                    <i class="fa fa-phone mx-2"></i>
                    <a class="navbar-sm-brand text-light text-decoration-none" href="tel:010-0000-0000">010-0000-0000</a>
                </div>
                <div>
                    <a class="text-light" target="_blank" href="https://www.ssafy.com/ksp/jsp/swp/swpMain.jsp"><i class="fas fa-desktop"></i></a>
                    <a class="text-light m-lg-3" target="_blank" href="https://github.com/daehyun1023"><i class="fas fa-male"></i></a>
                    <a class="text-light" target="_blank" href="https://github.com/eona1301"><i class="fas fa-female"></i></a>
                </div>
            </div>
        </div>
    </nav>
</template>

<script>
export default {
    name: 'TopNav'
}
</script>

<style scoped>
</style>