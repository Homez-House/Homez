<template>
  <div>
    <!-- Banner -->
    <section class="bg-success py-5">
      <div class="container">
        <div class="row align-items-center py-5">
          <div class="col-md text-white">
            <h1>Introduce Us</h1>
            <p>
              SSAFY 5기 서울 13반 소속으로 <b>안대현, 당현아</b>의 2인으로
              구성된 4팀입니다.<br />
              주택 정보를 제공하는 서비스의 정체성에 따라 Homes를 본따
              만들었습니다.<br />
            </p>
            <p>
              서로 부족한 부분을 채워주고 소통하는 것을 목표로 협업하였으며,<br />
              약 10일동안 잠에서 깨어나 다시 잠들 때까지 함께 진행하였습니다.<br />
              <br />
              웹 개발이 처음인 두 사람이 원하는 기능을 모두 구현한,<br />
              저희 만의 Homez 서비스를 소개합니다.<br />
            </p>
          </div>
          <div class="col-md">
            <img
              src="../assets/img/about.png"
              alt="About Hero"
              style="width: 600px"
            />
          </div>
        </div>
      </div>
    </section>
    <!-- Close Banner -->

    <!-- Start Section -->
    <section class="container py-5">
      <div class="row text-center pt-5 pb-3">
        <div class="col-lg-6 m-auto">
          <h1 class="h1">Service</h1>
          <p>
            실제 집을 검색하고 계약해 본 경험을 토대로, 원했었던 기능만을
            모았습니다.<br />
            단순 목록 뿐만이 아닌 본인이 필요로 하는 더욱 다양한 데이터를
            확인하여,<br />
            개인마다 다른 선정 기준을 적용할 수 있어 선택에 큰 도움을 제공할
            것입니다.<br />
          </p>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6 col-lg-3 pb-5">
          <div class="h-100 py-5 services-icon-wap shadow">
            <div class="h1 text-success text-center">
              <i class="fas fa-search"></i>
            </div>
            <h2 class="h5 mt-4 text-center">집값 검색</h2>
          </div>
        </div>

        <div class="col-md-6 col-lg-3 pb-5">
          <div class="h-100 py-5 services-icon-wap shadow">
            <div class="h1 text-success text-center">
              <i class="fas fa-sign-in-alt"></i>
            </div>
            <h2 class="h5 mt-4 text-center">관심지역 등록</h2>
          </div>
        </div>

        <div class="col-md-6 col-lg-3 pb-5">
          <div class="h-100 py-5 services-icon-wap shadow">
            <div class="h1 text-success text-center">
              <i class="fas fa-smog"></i>
            </div>
            <h2 class="h5 mt-4 text-center">주변정보</h2>
          </div>
        </div>

        <div class="col-md-6 col-lg-3 pb-5">
          <div class="h-100 py-5 services-icon-wap shadow">
            <div class="h1 text-success text-center">
              <i class="fa fa-user"></i>
            </div>
            <h2 class="h5 mt-4 text-center">24시 서비스</h2>
          </div>
        </div>
      </div>
    </section>
    <!-- End Section -->

    <!-- Start Stack -->
    <section class="bg-light py-5">
      <div class="container my-4">
        <div class="row text-center py-3">
          <div class="col-lg-6 m-auto">
            <h1 class="h1">Tech Stack</h1>
            <p>아래와 같은 기술을 활용하여 서비스를 구축하였습니다.</p>
          </div>
          <div class="col-lg-9 m-auto tempaltemo-carousel">
            <div class="row d-flex flex-row">
              <!--Controls-->
              <div class="col-1 align-self-center">
                <a
                  class="h1"
                  href="#templatemo-slide-brand"
                  role="button"
                  data-bs-slide="prev"
                >
                  <i class="text-light fas fa-chevron-left"></i>
                </a>
              </div>
              <!--End Controls-->

              <!--Carousel Wrapper-->
              <div class="col">
                <div
                  class="carousel slide carousel-multi-item pt-2 pt-md-0"
                  id="templatemo-slide-brand"
                  data-bs-ride="carousel"
                >
                  <!--Slides-->
                  <div class="carousel-inner product-links-wap" role="listbox">
                    <!--First slide-->
                    <div class="carousel-item active">
                      <div class="row">
                        <div class="col-3 p-md-5">
                          <a href="#"
                            ><img
                              class="img-fluid brand-img"
                              src="../assets/img/tech_01.png"
                              alt="Brand Logo"
                          /></a>
                        </div>
                        <div class="col-3 p-md-5">
                          <a href="#"
                            ><img
                              class="img-fluid brand-img"
                              src="../assets/img/tech_02.png"
                              alt="Brand Logo"
                          /></a>
                        </div>
                        <div class="col-3 p-md-5">
                          <a href="#"
                            ><img
                              class="img-fluid brand-img"
                              src="../assets/img/tech_03.png"
                              alt="Brand Logo"
                          /></a>
                        </div>
                        <div class="col-3 p-md-5">
                          <a href="#"
                            ><img
                              class="img-fluid brand-img"
                              src="../assets/img/tech_04.png"
                              alt="Brand Logo"
                          /></a>
                        </div>
                      </div>
                    </div>
                    <!--End First slide-->

                    <!--Second slide-->
                    <div class="carousel-item">
                      <div class="row">
                        <div class="col-3 p-md-5">
                          <a href="#"
                            ><img
                              class="img-fluid brand-img"
                              src="../assets/img/tech_05.png"
                              alt="Brand Logo"
                          /></a>
                        </div>
                        <div class="col-3 p-md-5">
                          <a href="#"
                            ><img
                              class="img-fluid brand-img"
                              src="../assets/img/tech_06.png"
                              alt="Brand Logo"
                          /></a>
                        </div>
                        <div class="col-3 p-md-5">
                          <a href="#"
                            ><img
                              class="img-fluid brand-img"
                              src="../assets/img/tech_07.png"
                              alt="Brand Logo"
                          /></a>
                        </div>
                        <div class="col-3 p-md-5">
                          <a href="#"
                            ><img
                              class="img-fluid brand-img"
                              src="../assets/img/tech_08.png"
                              alt="Brand Logo"
                          /></a>
                        </div>
                      </div>
                    </div>
                    <!--End Second slide-->

                    <!--Third slide-->
                    <div class="carousel-item">
                      <div class="row">
                        <div class="col-3 p-md-5">
                          <a href="#"
                            ><img
                              class="img-fluid brand-img"
                              src="../assets/img/tech_09.png"
                              alt="Brand Logo"
                          /></a>
                        </div>
                        <div class="col-3 p-md-5">
                          <a href="#"
                            ><img
                              class="img-fluid brand-img"
                              src="../assets/img/tech_10.png"
                              alt="Brand Logo"
                          /></a>
                        </div>
                        <div class="col-3 p-md-5">
                          <a href="#"
                            ><img
                              class="img-fluid brand-img"
                              src="../assets/img/tech_11.png"
                              alt="Brand Logo"
                          /></a>
                        </div>
                        <div class="col-3 p-md-5">
                          <a href="#"
                            ><img
                              class="img-fluid brand-img"
                              src="../assets/img/tech_12.png"
                              alt="Brand Logo"
                          /></a>
                        </div>
                      </div>
                    </div>
                    <!--End Third slide-->
                  </div>
                  <!--End Slides-->
                </div>
              </div>
              <!--End Carousel Wrapper-->

              <!--Controls-->
              <div class="col-1 align-self-center">
                <a
                  class="h1"
                  href="#templatemo-slide-brand"
                  role="button"
                  data-bs-slide="next"
                >
                  <i class="text-light fas fa-chevron-right"></i>
                </a>
              </div>
              <!--End Controls-->
            </div>
          </div>
        </div>
      </div>
    </section>
    <!--End Stack-->
  </div>
</template>

<script>
export default {
  name: "About",
};
</script>

<style>
</style>